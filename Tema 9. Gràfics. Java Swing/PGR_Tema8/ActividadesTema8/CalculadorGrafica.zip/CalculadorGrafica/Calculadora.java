package CalculadorGrafica;

import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;

public abstract class Calculadora extends JFrame implements ActionListener{

	JPanel a = (JPanel) this.getContentPane();
	JTextField screen = new JTextField();
	JButton btn0 = new JButton("0");
	JButton btn1 = new JButton("1");
	JButton btn2 = new JButton("2");
	JButton btn3 = new JButton("3");
	JButton btn4 = new JButton("4");
	JButton btn5 = new JButton("5");
	JButton btn6 = new JButton("6");
	JButton btn7 = new JButton("7");
	JButton btn8 = new JButton("8");
	JButton btn9 = new JButton("9");
	JButton btnsum = new JButton("+");
	JButton btnrest = new JButton("-");
	JButton btndiv = new JButton("/");
	JButton btnmult = new JButton("x");
	JButton btnpnt = new JButton(".");
	JButton btnigu = new JButton("=");
	JButton btnborr = new JButton("Borrar");
	private final JLabel label = new JLabel("New label");

	public Calculadora() {
		a.setLayout(null);
		setSize(400, 600);
		setTitle("Calculadora");
		setVisible(true);
		setResizable(false);
		screen.setForeground(Color.BLACK);
		screen.setBackground(Color.DARK_GRAY);
		screen.setHorizontalAlignment(SwingConstants.RIGHT);
	
		screen.setBounds(20, 8, 360, 90);
		screen.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		getContentPane().add(screen);
		
		btnborr.setBounds(20, 470, 360, 90);
		btnborr.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnborr.setForeground(new java.awt.Color(0, 0, 0));
		btnborr.setBackground(new java.awt.Color(179, 179, 179));
		getContentPane().add(btnborr);
		
		btn0.setBounds(20, 370, 90, 90);
		btn0.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn0.setForeground(new java.awt.Color(51, 51, 51));
		btn0.setBackground(new java.awt.Color(128, 128, 128));
		getContentPane().add(btn0);
		btn0.addActionListener(this);
		
		btnpnt.setBounds(110, 370, 90, 90);
		btnpnt.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnpnt.setForeground(new java.awt.Color(38, 38, 38));
		btnpnt.setBackground(new java.awt.Color(140, 140, 140));
		getContentPane().add(btnpnt);
		btnpnt.addActionListener(this);

		btnigu.setBounds(200, 370, 90, 90);
		btnigu.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnigu.setForeground(new java.awt.Color(26, 26, 26));
		btnigu.setBackground(new java.awt.Color(153, 153, 153));
		getContentPane().add(btnigu);
		btnigu.addActionListener(this);

		btnsum.setBounds(290, 370, 90, 90);
		btnsum.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnsum.setForeground(new java.awt.Color(13, 13, 13));
		btnsum.setBackground(new java.awt.Color(166, 166, 166));
		getContentPane().add(btnsum);
		btnsum.addActionListener(this);

		btn1.setBounds(20, 280, 90, 90);
		btn1.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn1.setForeground(new java.awt.Color(102, 102, 102));
		btn1.setBackground(new java.awt.Color(89, 89, 89));
		getContentPane().add(btn1);
		btn1.addActionListener(this);

		btn2.setBounds(110, 280, 90, 90);
		btn2.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn2.setForeground(new java.awt.Color(89, 89, 89));
		btn2.setBackground(new java.awt.Color(102, 102, 102));
		getContentPane().add(btn2);
		btn2.addActionListener(this);

		btn3.setBounds(200, 280, 90, 90);
		btn3.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn3.setForeground(new java.awt.Color(77, 77, 77));
		btn3.setBackground(new java.awt.Color(102, 102, 102));
		getContentPane().add(btn3);
		btn3.addActionListener(this);

		btnrest.setBounds(290, 280, 90, 90);
		btnrest.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnrest.setForeground(new java.awt.Color(64, 64, 64));
		btnrest.setBackground(new java.awt.Color(115, 115, 115));
		getContentPane().add(btnrest);
		btnrest.addActionListener(this);

		btn4.setBounds(20, 190, 90, 90);
		btn4.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn4.setForeground(new java.awt.Color(153, 153, 153));
		btn4.setBackground(new java.awt.Color(51, 51, 51));
		getContentPane().add(btn4);
		btn4.addActionListener(this);

		btn5.setBounds(110, 190, 90, 90);
		btn5.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn5.setForeground(new java.awt.Color(140, 140, 140));
		btn5.setBackground(new java.awt.Color(64, 64, 64));
		getContentPane().add(btn5);
		btn5.addActionListener(this);

		btn6.setBounds(200, 190, 90, 90);
		btn6.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn6.setForeground(new java.awt.Color(128, 128, 128));
		btn6.setBackground(new java.awt.Color(64, 64, 64));
		getContentPane().add(btn6);
		btn6.addActionListener(this);

		btnmult.setBounds(290, 190, 90, 90);
		btnmult.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btnmult.setForeground(new java.awt.Color(89, 89, 89));
		btnmult.setBackground(new java.awt.Color(115, 115, 115));
		getContentPane().add(btnmult);
		btnmult.addActionListener(this);

		btn7.setBounds(20, 100, 90, 90);
		btn7.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn7.setForeground(new java.awt.Color(204, 204, 204));
		btn7.setBackground(new java.awt.Color(0, 0, 0));
		getContentPane().add(btn7);
		btn7.addActionListener(this);

		btn8.setBounds(110, 100, 90, 90);
		btn8.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn8.setForeground(new java.awt.Color(191, 191, 191));
		btn8.setBackground(new java.awt.Color(13, 13, 13));
		getContentPane().add(btn8);
		btn8.addActionListener(this);

		btn9.setBounds(200, 100, 90, 90);
		btn9.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btn9.setForeground(new java.awt.Color(179, 179, 179));
		btn9.setBackground(new java.awt.Color(26, 26, 26));
		getContentPane().add(btn9);
		btn9.addActionListener(this);

		btndiv.setBounds(290, 100, 90, 90);
		btndiv.setFont(new Font("Yrsa Medium", Font.BOLD, 45));
		btndiv.setForeground(new java.awt.Color(166, 166, 166));
		btndiv.setBackground(new java.awt.Color(38, 38, 38));
		getContentPane().add(btndiv);
		btndiv.addActionListener(this);
		
		
		btnborr.addActionListener(this);	

		// Fondo
		label.setIcon(new ImageIcon("/home/pipo/eclipse-workspace/PGR_Tema9/ActividadesTema9/CalculadorGrafica/arc.gif"));
		label.setBounds(-111, -24, 734, 596);
		getContentPane().add(label);
	}
	
	public static void main(String[] args) {		
		OpCalculadora opCalc = new OpCalculadora();
		opCalc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent arg0) {
	}
}
